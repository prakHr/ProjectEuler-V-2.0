import sys

def main():
    print(sum(map(int, str(2**1000))))

if __name__ == '__main__':
    sys.exit(main())
