import math
import sys

def main():
    print(sum(map(int, str(math.factorial(100)))))

if __name__ == '__main__':
    sys.exit(main())
