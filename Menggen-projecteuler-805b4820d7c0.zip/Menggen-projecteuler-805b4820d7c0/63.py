import sys

def main():
    print([9**n for n in range(1, 22)])
    print([8**n for n in range(1, 11)])
    print([7**n for n in range(1, 7)])
    print([6**n for n in range(1, 5)])
    print([5**n for n in range(1, 4)])
    print([4**n for n in range(1, 3)])
    print([3**n for n in range(1, 2)])
    print([2**n for n in range(1, 2)])
    print([1**n for n in range(1, 2)])
    print(21 + 10 + 6 + 4 + 3 + 2 + 1 + 1 + 1)
    
if __name__ == '__main__':
    sys.exit(main())
